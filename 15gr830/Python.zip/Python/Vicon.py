
print("Go time")
import time as time
import viconReader as vic
import struct

print("imported")
V=vic.ViconReader()
print "test"
name = V.connect()
print "Connected"
for pkt,_ in zip(V.stream(),xrange(10)):
	print "%s" % (name)
	dat = struct.unpack("%dd" % (len(pkt)/8),pkt)
	print dat
  	# for nm,val in zip(name,dat):
   #       print nm,val
V.stop
V.close()
print "Disconnected"
print "end"